'use client';

import { useState, useMemo } from 'react';
import Image from 'next/image';
import { products as allProducts, type Product } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

export default function CustomizeRoomPage() {
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);

  const handleProductToggle = (product: Product) => {
    setSelectedProducts((prev) =>
      prev.find((p) => p.id === product.id)
        ? prev.filter((p) => p.id !== product.id)
        : [...prev, product]
    );
  };

  const totalPrice = useMemo(() => {
    return selectedProducts.reduce((total, product) => total + product.price, 0);
  }, [selectedProducts]);

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <div className="space-y-4 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-headline">Customize Your Room</h1>
        <p className="text-muted-foreground text-lg">
          Select items to furnish your room and see the total monthly cost.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Available Items</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[60vh]">
                <div className="space-y-4">
                  {allProducts.map((product: Product) => (
                    <div key={product.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-muted">
                      <Checkbox
                        id={`product-${product.id}`}
                        checked={selectedProducts.some((p) => p.id === product.id)}
                        onCheckedChange={() => handleProductToggle(product)}
                      />
                      <div className="flex-grow">
                        <Label htmlFor={`product-${product.id}`} className="font-medium">
                          {product.name}
                        </Label>
                        <p className="text-sm text-muted-foreground">₹{product.price}/month</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Your Customized Room</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-video w-full bg-gray-200 rounded-lg mb-6 overflow-hidden">
                <Image
                  src="https://picsum.photos/seed/empty-room/1200/675"
                  alt="Empty room background"
                  fill
                  className="object-cover"
                  data-ai-hint="empty room"
                />
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-2 gap-4 p-4">
                  {selectedProducts.map((product) => (
                    <div key={product.id} className="relative">
                      <Image
                        src={product.imageUrl}
                        alt={product.name}
                        fill
                        className="object-contain"
                        data-ai-hint={product.imageHint}
                      />
                    </div>
                  ))}
                </div>
              </div>
              
              <Separator className="my-4" />

              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold font-headline">Total Monthly Cost:</h3>
                <p className="text-3xl font-bold text-primary">₹{totalPrice.toFixed(2)}</p>
              </div>

              <Button size="lg" className="w-full mt-6">
                Proceed to Checkout
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
