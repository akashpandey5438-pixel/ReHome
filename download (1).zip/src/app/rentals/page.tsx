'use client';

import { useState, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { RentalCard } from '@/components/rental-card';
import { rentals as allRentals, type Rental } from '@/lib/data';
import { Search } from 'lucide-react';

const amenities: Rental['amenities'] = ['Wifi', 'AC', 'Parking', 'Furnished'];

export default function RentalsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState('all');

  const handleAmenityChange = (amenity: string) => {
    setSelectedAmenities((prev) =>
      prev.includes(amenity) ? prev.filter((a) => a !== amenity) : [...prev, amenity]
    );
  };

  const filteredRentals = useMemo(() => {
    return allRentals.filter((rental) => {
      const matchesSearch = rental.location.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesPrice =
        priceRange === 'all' ||
        (priceRange === 'under5000' && rental.price < 5000) ||
        (priceRange === '5000to10000' && rental.price >= 5000 && rental.price <= 10000) ||
        (priceRange === 'over10000' && rental.price > 10000);
      const matchesAmenities = selectedAmenities.every((amenity) =>
        rental.amenities.includes(amenity as any)
      );

      return matchesSearch && matchesPrice && matchesAmenities;
    });
  }, [searchTerm, priceRange, selectedAmenities]);

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <div className="space-y-4 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-headline">Find Your Next Home</h1>
        <p className="text-muted-foreground text-lg">Browse PGs and rooms tailored for you.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 p-4 border rounded-lg bg-card">
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search by location (e.g., Mumbai, Bengaluru)..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={priceRange} onValueChange={setPriceRange}>
          <SelectTrigger>
            <SelectValue placeholder="Price Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Prices</SelectItem>
            <SelectItem value="under5000">₹0 - ₹5,000</SelectItem>
            <SelectItem value="5000to10000">₹5,000 - ₹10,000</SelectItem>
            <SelectItem value="over10000">Over ₹10,000</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex flex-wrap items-center gap-4 md:col-span-4">
            <p className="font-medium text-sm mr-2">Amenities:</p>
            {amenities.map((amenity) => (
                <div key={amenity} className="flex items-center space-x-2">
                    <Checkbox
                        id={amenity}
                        checked={selectedAmenities.includes(amenity)}
                        onCheckedChange={() => handleAmenityChange(amenity)}
                    />
                    <Label htmlFor={amenity} className="text-sm font-normal">{amenity}</Label>
                </div>
            ))}
        </div>
      </div>

      {filteredRentals.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredRentals.map((rental) => (
            <RentalCard key={rental.id} rental={rental} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <h3 className="text-2xl font-semibold">No Rentals Found</h3>
          <p className="text-muted-foreground mt-2">Try adjusting your filters to find the perfect place.</p>
        </div>
      )}
    </div>
  );
}