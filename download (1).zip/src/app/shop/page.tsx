'use client';

import { useState, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ProductCard } from '@/components/product-card';
import { products as allProducts } from '@/lib/data';
import { Search } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

type ViewMode = 'rent' | 'buy';

export default function ShopPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');
  const [viewMode, setViewMode] = useState<ViewMode>('rent');

  const filteredProducts = useMemo(() => {
    return allProducts.filter((product) => {
      const price = viewMode === 'rent' ? product.price : product.purchasePrice;
      
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = category === 'all' || product.category === category;
      
      if (priceRange === 'all') {
        return matchesSearch && matchesCategory;
      }

      let matchesPrice = false;
      if (viewMode === 'rent') {
        if (priceRange === 'under2k') matchesPrice = price < 2000;
        else if (priceRange === '2kto4k') matchesPrice = price >= 2000 && price <= 4000;
        else if (priceRange === 'over4k') matchesPrice = price > 4000;
      } else { // buy mode
        if (priceRange === 'under10k') matchesPrice = price < 10000;
        else if (priceRange === '10kto25k') matchesPrice = price >= 10000 && price <= 25000;
        else if (priceRange === 'over25k') matchesPrice = price > 25000;
      }

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [searchTerm, category, priceRange, viewMode]);

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <div className="space-y-4 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-headline">Shop Refurbished Products</h1>
        <p className="text-muted-foreground text-lg">Find quality pre-owned items for your new beginning.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 p-4 border rounded-lg bg-card items-center">
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Furniture">Furniture</SelectItem>
            <SelectItem value="Electronics">Electronics</SelectItem>
            <SelectItem value="Appliances">Appliances</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priceRange} onValueChange={(value) => { setPriceRange(value); }}>
          <SelectTrigger>
            <SelectValue placeholder="Price Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Prices</SelectItem>
            {viewMode === 'rent' ? (
              <>
                <SelectItem value="under2k">Under ₹2,000</SelectItem>
                <SelectItem value="2kto4k">₹2,000 - ₹4,000</SelectItem>
                <SelectItem value="over4k">Over ₹4,000</SelectItem>
              </>
            ) : (
              <>
                <SelectItem value="under10k">Under ₹10,000</SelectItem>
                <SelectItem value="10kto25k">₹10,000 - ₹25,000</SelectItem>
                <SelectItem value="over25k">Over ₹25,000</SelectItem>
              </>
            )}
          </SelectContent>
        </Select>
        <div className="md:col-span-4 flex items-center justify-center space-x-2">
            <Label htmlFor="view-mode-switch">Rent</Label>
            <Switch
              id="view-mode-switch"
              checked={viewMode === 'buy'}
              onCheckedChange={(checked) => {
                setViewMode(checked ? 'buy' : 'rent');
                setPriceRange('all'); // Reset price range when view mode changes
              }}
            />
            <Label htmlFor="view-mode-switch">Buy</Label>
          </div>
      </div>

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} viewMode={viewMode} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <h3 className="text-2xl font-semibold">No Products Found</h3>
          <p className="text-muted-foreground mt-2">Try adjusting your filters.</p>
        </div>
      )}
    </div>
  );
}
