import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Handshake, HeartHandshake, ListPlus, Truck } from 'lucide-react';
import { products, rentals } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { RentalCard } from '@/components/rental-card';

export default function Home() {
  const featuredProducts = products.slice(0, 3);
  const featuredRentals = rentals.slice(0, 3);

  const howItWorks = [
    {
      icon: <ListPlus className="h-10 w-10" />,
      title: '1. List Your Item',
      description: 'Easily list your used furniture and electronics on our platform.',
    },
    {
      icon: <Handshake className="h-10 w-10" />,
      title: '2. Get an Offer',
      description: 'We review your item and provide a fair and competitive offer.',
    },
    {
      icon: <Truck className="h-10 w-10" />,
      title: '3. We Collect & Pay',
      description: 'Schedule a pickup, and get paid instantly upon collection.',
    },
    {
      icon: <HeartHandshake className="h-10 w-10" />,
      title: '4. It Gets a New Home',
      description: 'We refurbish your item and find it a new loving home.',
    },
  ];

  return (
    <div className="flex flex-col min-h-[100dvh]">
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gray-100/50 dark:bg-gray-800/50">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none font-headline text-primary">
                  Your Home, Reimagined
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  ReHome makes it easy for bachelors and students to sell used goods and find great PGs and rooms.
                  Sustainable living starts here.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg" className="font-semibold">
                  <Link href="/rentals">
                    Find a Place
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="secondary" className="font-semibold">
                  <Link href="/sell">Sell Your Stuff</Link>
                </Button>
              </div>
            </div>
            <Image
              src="https://images.unsplash.com/photo-1484154218962-a197022b5858?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wzNjAzNTV8MHwxfHNlYXJjaHwxfHxmbGF0JTIwaW50ZXJpb3J8ZW58MHx8fHwxNjY2ODg3NzY4fDA&ixlib=rb-4.0.3&q=80&w=1080"
              width={1200}
              height={800}
              alt="Hero"
              data-ai-hint="modern kitchen"
              className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last lg:aspect-square"
            />
          </div>
        </div>
      </section>

      <section id="products" className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">Shop Refurbished Goods</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Quality items at unbeatable prices. Give pre-loved items a second chance.
              </p>
            </div>
          </div>
          <div className="mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} viewMode="rent" />
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild>
              <Link href="/shop">
                Shop All Products <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section id="rentals" className="w-full py-12 md:py-24 lg:py-32 bg-gray-100/50 dark:bg-gray-800/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">Find Your Next Home</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Discover the best PGs and rooms in your new city. Curated for students and bachelors.
              </p>
            </div>
          </div>
          <div className="mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {featuredRentals.map((rental) => (
              <RentalCard key={rental.id} rental={rental} />
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild>
              <Link href="/rentals">
                See All Rentals <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section id="how-it-works" className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">How It Works</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Selling your used items with ReHome is simple and rewarding.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 md:gap-12 lg:grid-cols-4 mt-12">
            {howItWorks.map((step) => (
              <Card key={step.title} className="text-center border-0 shadow-none bg-transparent">
                <CardContent className="flex flex-col items-center gap-4 p-6">
                  <div className="bg-primary/10 text-primary p-4 rounded-full">
                    {step.icon}
                  </div>
                  <h3 className="text-lg font-bold font-headline">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
