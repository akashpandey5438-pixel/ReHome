import Image from 'next/image';
import type { Product } from '@/lib/data';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck } from 'lucide-react';

type ProductCardProps = {
  product: Product;
  viewMode: 'rent' | 'buy';
};

export function ProductCard({ product, viewMode }: ProductCardProps) {
  const isBuyMode = viewMode === 'buy';

  return (
    <Card className="flex flex-col overflow-hidden h-full transition-shadow hover:shadow-lg">
      <CardHeader className="p-0">
        <div className="aspect-video relative">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover"
            data-ai-hint={product.imageHint}
          />
        </div>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <div className="flex justify-between items-start gap-2">
            <CardTitle className="text-lg font-headline mb-2">{product.name}</CardTitle>
            <Badge variant="secondary">{product.category}</Badge>
        </div>
        <p className="text-muted-foreground text-sm line-clamp-2">{product.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <div>
          {isBuyMode ? (
            <>
              <p className="text-xl font-bold text-primary">₹{product.purchasePrice.toLocaleString()}</p>
              <div className="flex items-center text-xs text-muted-foreground gap-1">
                <ShieldCheck className="h-3 w-3" />
                <span>{product.warranty} warranty</span>
              </div>
            </>
          ) : (
            <>
              <p className="text-xl font-bold text-primary">₹{product.price.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">/ month</p>
            </>
          )}
        </div>
        <Button>{isBuyMode ? 'Buy Now' : 'Rent Now'}</Button>
      </CardFooter>
    </Card>
  );
}