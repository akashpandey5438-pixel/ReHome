import Image from 'next/image';
import type { Rental } from '@/lib/data';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Wifi, ParkingCircle, AirVent, BedDouble } from 'lucide-react';
import { cn } from '@/lib/utils';

type RentalCardProps = {
  rental: Rental;
};

const amenityIcons = {
  Wifi: <Wifi className="h-4 w-4" />,
  AC: <AirVent className="h-4 w-4" />,
  Parking: <ParkingCircle className="h-4 w-4" />,
  Furnished: <BedDouble className="h-4 w-4" />,
};

export function RentalCard({ rental }: RentalCardProps) {
  return (
    <Card className="flex flex-col overflow-hidden h-full transition-shadow hover:shadow-lg">
      <CardHeader className="p-0 relative">
        <div className="aspect-video">
          <Image
            src={rental.imageUrl}
            alt={rental.title}
            fill
            className="object-cover"
            data-ai-hint={rental.imageHint}
          />
        </div>
        <Badge className={cn("absolute top-2 right-2", rental.type === 'PG' ? 'bg-blue-500' : 'bg-green-500')}>{rental.type}</Badge>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <CardTitle className="text-lg font-headline mb-2">{rental.title}</CardTitle>
        <div className="flex items-center text-muted-foreground text-sm mb-3">
            <MapPin className="h-4 w-4 mr-1"/>
            <span>{rental.location}</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
            {rental.amenities.map(amenity => (
                <Badge key={amenity} variant="outline" className="flex items-center gap-1">
                    {amenityIcons[amenity]}
                    {amenity}
                </Badge>
            ))}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <div>
            <p className="text-xl font-bold text-primary">₹{rental.price.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">/ month</p>
        </div>
        <Button>Book Now</Button>
      </CardFooter>
    </Card>
  );
}