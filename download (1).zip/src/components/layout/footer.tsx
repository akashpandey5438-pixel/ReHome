"use client";

import Link from "next/link";
import { Logo } from "@/components/icons";
import { useState, useEffect } from "react";

export function Footer() {
  const [year, setYear] = useState(new Date().getFullYear());

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  return (
    <footer className="bg-background border-t">
      <div className="container mx-auto flex flex-col items-center justify-between gap-6 px-4 py-8 md:flex-row md:px-6">
        <div className="flex items-center gap-2">
          <Logo className="h-6 w-6 text-primary" />
          <span className="font-headline text-lg font-bold">ReHome</span>
        </div>
        <nav className="flex flex-wrap items-center justify-center gap-4 text-sm font-medium md:gap-6">
          <Link href="/shop" className="transition-colors hover:text-primary">
            Shop
          </Link>
          <Link href="/rentals" className="transition-colors hover:text-primary">
            Rentals
          </Link>
          <Link href="/sell" className="transition-colors hover:text-primary">
            Sell
          </Link>
          <Link href="/#how-it-works" className="transition-colors hover:text-primary">
            How It Works
          </Link>
        </nav>
        <p className="text-sm text-muted-foreground">&copy; {year} ReHome. All rights reserved.</p>
      </div>
    </footer>
  );
}
