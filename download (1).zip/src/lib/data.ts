
export type Product = {
  id: number;
  name: string;
  category: 'Furniture' | 'Electronics' | 'Appliances';
  price: number; // Monthly rental price
  purchasePrice: number; // One-time purchase price
  warranty: string; // e.g., "1 Year"
  imageUrl: string;
  imageHint: string;
  description: string;
};

export type Rental = {
  id: number;
  title: string;
  type: 'PG' | 'Room';
  location: string;
  price: number;
  amenities: ('Wifi' | 'AC' | 'Parking' | 'Furnished')[];
  imageUrl: string;
  imageHint: string;
};

export const products: Product[] = [
  {
    id: 1,
    name: 'Modern Gray Sofa',
    category: 'Furniture',
    price: 4500,
    purchasePrice: 25000,
    warranty: '1 Year',
    imageUrl: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxzb2ZhfGVufDB8fHx8MTc1Njc1MTU0N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'modern sofa',
    description: 'A comfortable and stylish modern gray sofa, perfect for any living room. Lightly used.'
  },
  {
    id: 2,
    name: '4K Smart TV 55"',
    category: 'Electronics',
    price: 3500,
    purchasePrice: 40000,
    warranty: '1 Year',
    imageUrl: 'https://images.unsplash.com/photo-1567690187548-f07b1d7bf5a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxM3x8c21hcnQlMjB0dnxlbnwwfHx8fDE3NTY3NTE1MDN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'smart tv',
    description: 'A 55-inch 4K Smart TV with all the latest apps. Excellent condition with original remote.'
  },
  {
    id: 3,
    name: 'Compact Refrigerator',
    category: 'Appliances',
    price: 2000,
    purchasePrice: 15000,
    warranty: '6 Months',
    imageUrl: 'https://images.unsplash.com/photo-1722603929403-de9e80c46a9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxM3x8cmVmcmlnZXJhdG9yfGVufDB8fHx8MTc1Njc1MTYwMnww&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'small refrigerator',
    description: 'A space-saving compact refrigerator, ideal for small apartments or dorm rooms.'
  },
  {
    id: 4,
    name: 'Wooden Coffee Table',
    category: 'Furniture',
    price: 1500,
    purchasePrice: 8000,
    warranty: '6 Months',
    imageUrl: 'https://images.unsplash.com/photo-1692262089751-7e26b69ad8d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMnx8d29vZGVuJTIwY29mZmVlJTIwdGFibGV8ZW58MHx8fHwxNzU3MzUwMDUwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'coffee table',
    description: 'A sturdy wooden coffee table with a rustic finish. Adds character to any space.'
  },
  {
    id: 5,
    name: 'Microwave Oven',
    category: 'Appliances',
    price: 1000,
    purchasePrice: 6000,
    warranty: '1 Year',
    imageUrl: 'https://images.unsplash.com/photo-1626143508000-4b5904e5e84a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxtaWNyb3dhdmUlMjBvdmVufGVufDB8fHx8MTc1NzM1MDE3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'microwave oven',
    description: 'A reliable and easy-to-use microwave oven. Perfect for quick meals.'
  },
  {
    id: 6,
    name: 'Bluetooth Speaker',
    category: 'Electronics',
    price: 800,
    purchasePrice: 4500,
    warranty: '6 Months',
    imageUrl: 'https://images.unsplash.com/photo-1529359744902-86b2ab9edaea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxzcGVha2VyfGVufDB8fHx8MTc1NzM1MDI3M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'bluetooth speaker',
    description: 'A portable Bluetooth speaker with great sound quality and long battery life.'
  },
];

export const rentals: Rental[] = [
  {
    id: 1,
    title: 'Cozy Room in Downtown',
    type: 'Room',
    location: 'Mumbai, MH',
    price: 8000,
    amenities: ['Wifi', 'AC', 'Furnished'],
    imageUrl: 'https://images.unsplash.com/photo-1657040899601-fbcc8f6486f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxM3x8Y296eSUyMHJvb218ZW58MHx8fHwxNzU3MzUwNTI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'cozy bedroom'
  },
  {
    id: 2,
    title: 'Modern PG for Students',
    type: 'PG',
    location: 'Bengaluru, KA',
    price: 6500,
    amenities: ['Wifi', 'Parking'],
    imageUrl: 'https://images.unsplash.com/photo-1515829231605-2d8e4455af56?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxtb2Rlcm4lMjBwZ3N8ZW58MHx8fHwxNzU3MzUwNjEyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'modern hostel'
  },
  {
    id: 3,
    title: 'Spacious Room with a View',
    type: 'Room',
    location: 'Delhi, DL',
    price: 9500,
    amenities: ['Wifi', 'AC', 'Parking', 'Furnished'],
    imageUrl: 'https://images.unsplash.com/photo-1547426562-ffa17ebb4ca0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxOHx8cm9vbSUyMHdpdGglMjBncmVlbiUyMHZpZXd8ZW58MHx8fHwxNzU3MzUwNzA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'apartment view'
  },
  {
    id: 4,
    title: 'Affordable PG near Tech Park',
    type: 'PG',
    location: 'Pune, MH',
    price: 5000,
    amenities: ['Wifi', 'AC'],
    imageUrl: 'https://images.unsplash.com/photo-1695204905741-9d099a5989ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxob3N0ZWx8ZW58MHx8fHwxNzU3MzUwODg5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'student accommodation'
  },
  {
    id: 5,
    title: 'Shared Room for Bachelors',
    type: 'Room',
    location: 'Hyderabad, TS',
    price: 4000,
    amenities: ['Wifi', 'Furnished'],
    imageUrl: 'https://images.unsplash.com/photo-1598147265504-899fbf4b5500?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMXx8c2hhcmVkJTIwcm9vbXN8ZW58MHx8fHwxNzU3MzUwOTcxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'shared bedroom'
  },
  {
    id: 6,
    title: 'Executive PG with All Amenities',
    type: 'PG',
    location: 'Chennai, TN',
    price: 11000,
    amenities: ['Wifi', 'AC', 'Parking', 'Furnished'],
    imageUrl: 'https://images.unsplash.com/photo-1623625434462-e5e42318ae49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxob3N0ZWx8ZW58MHx8fHwxNzU3MzUwODg5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    imageHint: 'luxury apartment'
  },
];
